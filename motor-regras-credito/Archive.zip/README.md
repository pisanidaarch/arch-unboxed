# arch-unboxed
# Motor de Regras de Aprovação de Crédito

Este projeto implementa um Motor de Regras para processamento de solicitações de crédito, aplicando regras predefinidas e dinâmicas para determinar se uma solicitação deve ser aprovada, reprovada ou encaminhada para análise manual.

## Arquitetura

O sistema segue uma arquitetura em camadas:

1. **Camada Service** - Contém o Motor (Façade) como ponto de entrada
2. **Camada Core** - Contém a lógica de avaliação e o Gerenciador de Cenário
3. **Camada Entity** - Contém a definição do objeto Cenário
4. **Camada Adapter** - Contém adaptadores para sistemas externos

## Padrões de Projeto Utilizados

- **Façade**: Motor como ponto de entrada simplificado para o sistema
- **Adapter**: Integração com sistemas externos
- **Chain of Responsibility**: Processamento sequencial de regras
- **Specification**: Validação de regras mandatórias
- **Strategy**: Implementação de regras dinâmicas

## Requisitos

- Node.js 14+
- npm ou yarn

## Como Iniciar o Projeto

### Criação da Estrutura de Pastas

```bash
mkdir -p motor-regras-credito/src/{service,core/{chain/handlers,specifications,strategies},entity,adapter,api/{controllers,routes,middleware},config,utils/errors} motor-regras-credito/tests/{unit,integration,e2e}
cd motor-regras-credito
```

### Instalação

```bash
# Inicializar o projeto
npm init -y

# Instalar dependências
npm install express helmet cors

# Instalar dependências de desenvolvimento
npm install --save-dev jest supertest nodemon
```

### Scripts Disponíveis

- `npm start`: Inicia a aplicação em modo produção
- `npm run dev`: Inicia a aplicação em modo desenvolvimento com hot-reload
- `npm test`: Executa os testes
- `npm run test:watch`: Executa os testes em modo watch
- `npm run test:coverage`: Executa os testes com relatório de cobertura

## Como Usar a API

### Endpoints

#### Verificação de Saúde

```
GET /health
```

Resposta:
```json
{
  "status": "ok",
  "message": "Serviço disponível",
  "timestamp": "2023-04-05T12:00:00.000Z"
}
```

#### Analisar Crédito

```
POST /api/credito/analisar
```

Corpo da Requisição:
```json
{
  "clienteId": "string",
  "valorCredito": "decimal",
  "parametrosAdicionais": {
    "chave1": "valor1",
    "chave2": "valor2"
  }
}
```

Resposta:
```json
{
  "status": "string", // APROVADO, REPROVADO, ANALISE_MANUAL
  "idCenario": "string",
  "mensagem": "string",
  "detalhesAvaliacao": [
    {
      "regra": "string",
      "resultado": "boolean",
      "descricao": "string"
    }
  ],
  "dadosAdicionais": {
    "chave1": "valor1",
    "chave2": "valor2"
  }
}
```

## Executando com Docker

```bash
# Construir a imagem
docker build -t motor-regras-credito .

# Executar o container
docker run -p 3000:3000 motor-regras-credito

# Alternativamente, usando docker-compose
docker-compose up
```

## Estrutura do Projeto

```
/
├── src/
│   ├── service/                # Camada de Serviço
│   │   ├── Motor.js            # Façade principal (entry point)
│   │   └── LogService.js       # Serviço de logs
│   │
│   ├── core/                   # Camada Core
│   │   ├── GerenciadorCenario.js  # Gerenciador de Cenário
│   │   ├── chain/              # Chain of Responsibility
│   │   │   ├── ChainOfResponsibility.js
│   │   │   └── handlers/       # Handlers da cadeia
│   │   │       ├── RegrasMandatoriasHandler.js
│   │   │       ├── RegrasDinamicasHandler.js
│   │   │       └── RequisicaoIAHandler.js
│   │   │
│   │   ├── specifications/     # Regras Mandatórias (Specification)
│   │   │   ├── Specification.js
│   │   │   ├── IdadeMinimaMandatoriaSpecification.js
│   │   │   ├── ScoreMinimoMandatorioSpecification.js
│   │   │   └── ...
│   │   │
│   │   └── strategies/         # Regras Dinâmicas (Strategy)
│   │       ├── Strategy.js
│   │       ├── ComprometimentoRendaStrategy.js
│   │       └── ...
│   │
│   ├── entity/                 # Camada Entity
│   │   ├── Cenario.js          # Entidade Cenário
│   │   └── ResultadoIA.js      # Resultado da IA
│   │
│   ├── adapter/                # Camada Adapter
│   │   ├── Adapter.js          # Interface base para adaptadores
│   │   ├── BureauCreditoAdapter.js
│   │   ├── DadosClienteAdapter.js
│   │   ├── OpenBankingAdapter.js
│   │   └── IAAdapter.js
│   │
│   ├── api/                    # API e Controllers
│   │   ├── controllers/
│   │   │   └── CreditoController.js
│   │   ├── routes/
│   │   │   └── creditoRoutes.js
│   │   └── middleware/
│   │       └── errorHandler.js
│   │
│   ├── config/                 # Configurações
│   │   ├── app.js
│   │   ├── database.js
│   │   └── logger.js
│   │
│   └── utils/                  # Utilitários
│       └── errors/
│           └── CustomErrors.js
│
├── tests/                      # Testes
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── package.json
├── README.md
└── .env.example
```

## Licença

ISC