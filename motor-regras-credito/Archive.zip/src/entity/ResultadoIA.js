// src/entity/ResultadoIA.js

class ResultadoIA {
    constructor(aprovado, justificativa, confianca) {
      this.aprovado = aprovado;
      this.justificativa = justificativa;
      this.confianca = confianca;
    }
  }
  
  module.exports = ResultadoIA;